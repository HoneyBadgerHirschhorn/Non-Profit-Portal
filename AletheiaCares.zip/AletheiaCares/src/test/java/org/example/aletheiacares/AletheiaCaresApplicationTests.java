package org.example.aletheiacares;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AletheiaCaresApplicationTests {

    @Test
    void contextLoads() {
    }

}
