package org.example.aletheiacares;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelpRequestService {

    @Autowired
    private HelpRequestRepository helpRequestRepository;

    public HelpRequest saveHelpRequest(HelpRequest helpRequest) {
        return helpRequestRepository.save(helpRequest);
    }
}



